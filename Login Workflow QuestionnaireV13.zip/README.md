
  # Login Workflow Questionnaire

  This is a code bundle for Login Workflow Questionnaire. The original project is available at https://www.figma.com/design/BaKUamTgo9Nbe64brlTbFg/Login-Workflow-Questionnaire.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  